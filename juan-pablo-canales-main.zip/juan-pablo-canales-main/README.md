# Juan Pablo Canales

Diseñador gráfico.

Dirección de arte y Editorial en Simple Comunicación.

Cine, libros y videojuegos. @jotapecanales

![fotitook](https://github.com/diplomado-infografia/juan-pablo-canales/assets/137964679/2b7d15e2-c11a-4868-a0f3-76760e207cdf)

