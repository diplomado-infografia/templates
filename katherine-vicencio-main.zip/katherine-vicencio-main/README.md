# katherine-vicencio![ImagenMETA](https://github.com/diplomado-infografia/katherine-vicencio/assets/137964704/586774ca-86ac-42d6-9693-3ab1465b1db1)
