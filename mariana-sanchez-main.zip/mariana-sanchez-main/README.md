# mariana-sanchez
![imagen-metadato](https://github.com/diplomado-infografia/mariana-sanchez/blob/main/img/imagen-metadatos.jpg)
